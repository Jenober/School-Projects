var json = {

    // Various objects with properties, attributes, etc.

    "Default1":{

        "Date": ["Date: ", "12/12/12"],
        "Name": ['Name: ', "Darmok Un'Jalad Attinagra"],
        'Race': ['Race: ', 'Dwarf'],
        "Size": ['Size: ', "Tiny"],
        "Age": ['Age: ', "132"],
        "Gender": ["Sex: ",'Male'],
        "Str": ['Strength: ', '10'],
        "Con": ['Constitution: ', '10'],
        "Dex": ['Dexterity: ','10'],
        "Int": ['Intelligence: ','10'],
        "Wis": ['Wisdom: ','10'],
        "Cha": ['Charisma: ', '10'],
        "Bio": ['Biography: ', '10']

    },

    "Default2":{

        "Date": ["Date: ", "12/12/12"],
        "Name": ['Name: ', "Trix Arfur Kitz"],
        "Race": ['Race: ', 'Human'],
        "Size": ['Size: ', "Tiny"],
        "Age": ['Age: ', "32"],
        "Gender": ["Sex: ",'Male'],
        "Str": ['Strength: ', '11'],
        "Con": ['Constitution: ', '11'],
        "Dex": ['Dexterity: ','11'],
        "Int": ['Intelligence: ','11'],
        "Wis": ['Wisdom: ','11'],
        "Cha": ['Charisma: ', '11'],
        "Bio": ['Biography: ', '11']

    }




}
