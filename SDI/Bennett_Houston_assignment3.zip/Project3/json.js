// Houston Bennett
// SDI 1211
// Project 3 JSON data



var cars = [
    // All the properties
    {
        //Object property
        "driver" : {

            "name" : "Houston",
            "skill" : "novice",
            "wins" : 2,
            "isReady" : false,
            "cash" : 5000
        },
        //Boolean property
        "hasNOS" : "True",
        //Array property
        "engineMods" : ["Headers", "Intake", "Turbo"],
        //Number property
        "horsepower" : 252,
        //String property
        "carModel" : "BMW"
    },
    {
        "driver" : {

            "name" : "Nat",
            "skill" : "novice",
            "wins" : 0,
            "isReady" : true,
            "cash" : 10000
        },
        "hasNOS" : "True",
        "engineMods" : ["Headers", "Intake", "Turbo"],
        "horsepower" : 192,
        "carModel" : "Honda"


    },
    {
        "driver" : {
            "name" : "Eric",
            "skill" : "novice",
            "wins" : 10,
            "isReady" : true,
            "cash" : 25000
        },
        "hasNOS" : false,
        "engineMods" : ["Headers", "Intake", "Turbo"],
        "horsepower" : 210,
        "carModel" : "Volkswagen"
    }
        ];








